# Project Summary — SQL Analysis (COVID-19)

## Problem statement
Compare COVID-19 trends across countries and evaluate possible correlation with vaccination.

## Data source
Our World in Data - https://ourworldindata.org/coronavirus

## Key findings
- Finding 1: ...
- Finding 2: ...

## Recommendations
- Recommendation 1
- Recommendation 2

## Limitations
- Data completeness varies by country.
- Reporting differences by date.
